@echo off

cd /d "%~dp0"

start "" /b node local_server.js

start "" cmd /k ngrok http 3000

title Local Server (Developed By Veldenoire)

:menu
cls
COLOR 05

echo === Command ===
echo * Close: Close server
set /p command= 
if "%command%"=="Close" goto exit
if "%command%"=="SetKey" set /p owner=ID:
if not "%owner%" =="" echo %owner% > owner.ldx 

goto menu

:exit
echo Closing...

:: kill semua process terkait (ini dari gpt im newbie soalnya)
taskkill /f /im node.exe >nul 2>&1
taskkill /f /im ngrok.exe >nul 2>&1

exit