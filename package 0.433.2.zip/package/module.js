
async function shownotif(){
    if (Notification.permission !== "granted"){
        await Notification.requestPermission()

    }
    if (Notification.permission === "granted"){
        new Notification("Client Manager",{
            body:"New client connected",
            icon:"https://tr.rbxcdn.com/180DAY-45cf2dee64574c9210fac51604cdbd6a/150/150/Image/Webp/noFilter"
        })
    }
}
