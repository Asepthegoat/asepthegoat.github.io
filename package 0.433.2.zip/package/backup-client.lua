--[[

__| |___________________________________________________________________________________________________________________________________| |__
__   ___________________________________________________________________________________________________________________________________   __
  | |                                                                                                                                   | |  
  | |██╗     ██╗███████╗██╗  ██╗     ██████╗ ██████╗  ██████╗██╗  ██╗███████╗███████╗████████╗██████╗  █████╗ ████████╗ ██████╗ ██████╗ | |  
  | |██║     ██║██╔════╝╚██╗██╔╝    ██╔═══██╗██╔══██╗██╔════╝██║  ██║██╔════╝██╔════╝╚══██╔══╝██╔══██╗██╔══██╗╚══██╔══╝██╔═══██╗██╔══██╗| |  
  | |██║     ██║█████╗   ╚███╔╝     ██║   ██║██████╔╝██║     ███████║█████╗  ███████╗   ██║   ██████╔╝███████║   ██║   ██║   ██║██████╔╝| |  
  | |██║     ██║██╔══╝   ██╔██╗     ██║   ██║██╔══██╗██║     ██╔══██║██╔══╝  ╚════██║   ██║   ██╔══██╗██╔══██║   ██║   ██║   ██║██╔══██╗| |  
  | |███████╗██║███████╗██╔╝ ██╗    ╚██████╔╝██║  ██║╚██████╗██║  ██║███████╗███████║   ██║   ██║  ██║██║  ██║   ██║   ╚██████╔╝██║  ██║| |  
  | |╚══════╝╚═╝╚══════╝╚═╝  ╚═╝     ╚═════╝ ╚═╝  ╚═╝ ╚═════╝╚═╝  ╚═╝╚══════╝╚══════╝   ╚═╝   ╚═╝  ╚═╝╚═╝  ╚═╝   ╚═╝    ╚═════╝ ╚═╝  ╚═╝| |  
__| |___________________________________________________________________________________________________________________________________| |__
__   ___________________________________________________________________________________________________________________________________   __
  | |                                                                                                                                   | |   

Beta 0.1
]]
getgenv().RemoteSocket = {
    MainUrl = "",
    Status = false,
    ClientId = getplayer().UserId,
    RemoteCom = {} --just make this one empty dont fill it dude
}

loadstring(game:HttpGet("https://raw.githubusercontent.com/Asepthegoat/LIUDEX-Z/refs/heads/main/script/tools/functions.lua"))() --LIB DON'T REMOVE THIS
--[[
work flow no nword count without skid gui
":;:" its used for invoke server
" | " its use for firesocket
"InvokeServer" used only for firing server to run code on server and didnt affected to client
or you can use POST method to invoke server
"FireSocket" used only for firing all client(reciver) to run code from sender and didnt affected annything on server

--[DISCLAIMER]--

+ it is recommended to add a prefix to your remote name, for example ldxbring instead of just bring.
+ client Script reciever require to be same Script or Code to each other
+ you can only send string use serialize script to make your string looks like normal code and run it with  if you want
+ oprator
 - @all to fire all client that connect
 - @server to fire all client that connect and in same server(placeid and gameid) with you server
+ remote Example:
+ Socket:FireSocket(remote,target or oprator,args)
[ Developed By Lorem Ipsum Familia Developer ]

]]
local TextChatService = import.TextChatService
function fakeChat(target,msg)
    local plr = import.Players[target]
    local head =plr.Character.Head
    TextChatService:DisplayBubble(head, msg)
    local channel = TextChatService:WaitForChild("TextChannels"):WaitForChild("RBXGeneral")
    channel:DisplaySystemMessage('<font color="rgb(255,0,0)">' .. plr.Name .. ': </font>' .. msg)
end

if getgenv().RemoteSocket and getgenv().RemoteSocket.Status == true then
    return warn("Socket is already exist close it first by using:\nSocket:CloseSession()")
end

getgenv().Socket = {}
local RemoteSocket = getgenv().RemoteSocket
function Socket:SetMain(url)
    RemoteSocket.MainUrl = url
    if not RemoteSocket.Status then
        RemoteSocket.Status = true
        RemoteSocket.RemoteCom = {}
        RemoteSocket.Invoker = {}
        RemoteSocket.ClientId = getplayer().UserId
    end
end
Socket:SetMain("wss://xochitl-superexacting-unconcentrically.ngrok-free.dev")
repeat
task.wait(0.2)    
until getgenv().RemoteSocket.MainUrl 

local Players = import.Players
local sockets = WebSocket.connect(RemoteSocket.MainUrl)
sockets.OnClose:Connect(function()
    print("Session Clossed")
end)

sockets.OnMessage:Connect(function(msg)
    if not RemoteSocket.Status then
        RemoteSocket.Status = true
    end
    print("recive",msg)
    local args = string.split(msg," | ")
    local name = args[1]
    local id = args[2]
    local op = args[3]
    local func =  RemoteSocket.RemoteCom[name].func
    local argue = table.concat(args,",",4)
    local argument = string.split(argue,",",1)
    local serverdata = args[3]:split(";")
    local job = serverdata[3]
    local place = serverdata[2]
    local selfop 
    if op == "@all" or op == "@global" then
        func(id,unpack(argument))
    elseif import.Players[op:gsub("@","")] then
        selfop = getplayer().Parent[op:gsub("@","")]
    elseif op:find("@server") then
        local serverdat = op:split(";")
        local place = serverdat[2]
        local jobid = serverdat[3]
        if tonumber(place) == game.PlaceId and jobid == game.JobId then
            func(id,unpack(argument))
        end
    end
    if selfop then
        if compareinstances(selfop, getplayer()) then
            func(id,unpack(argument))
        end
    end
end)

function Socket:CloseSession()
    sockets:Close()
    getgenv().RemoteSocket = nil
    print("Clossed")
end

function Socket.new(name,func)
    if name and typeof(name) == "string" then
        if not RemoteSocket.RemoteCom[name] then
            local remote = {}
            remote.Id = RemoteSocket.ClientId
            remote.Name = name
            remote.func = func
            setmetatable(remote,{__index = Socket})
            RemoteSocket.RemoteCom[name] = remote
            return RemoteSocket.RemoteCom[name]
        end
        return error(name,"is alread exist")
    end
    error("name must be string")
end

function Socket.request(name,call)
    if name and typeof(name) == "string" then
        if not RemoteSocket.RemoteCom[name] then
            local remote = {}
            remote.Id = RemoteSocket.ClientId
            remote.Name = name
            remote.func = func
            setmetatable(remote,{__index = Socket})
            RemoteSocket.RemoteCom[name] = remote
            return RemoteSocket.RemoteCom[name]
        end
        return error(name,"is alread exist")
    end
    error("name must be string")
end

function Socket:FireSocket(op,...)
    local args = {...}
    if op == "@server" then
        op = op .. ";" .. game.PlaceId .. ";" .. game.JobId
    end
    local value = self.Name .. " | " .. tostring(self.Id) .. " | "  .. op .. " | " ..table.concat(args,",",1)
    sockets:Send(value)
end
Socket.FireServer = Socket.FireSocket

function Socket:InvokeServer(remote,client,...)
    local args = {...}
    local value = remote.Name .. ":;:" .. tostring(remote.Id) .. ":;:"  .. tostring(client) .. ":;:" ..table.concat(args," ",1)
    sockets:Send(value)
end

function Socket:Request(tabl)
    local url = RemoteSocket.MainUrl
    if RemoteSocket.MainUrl:find("wss") then
        url = RemoteSocket.MainUrl:sub("wss","https")
    elseif RemoteSocket.MainUrl:find("ws") then
        url = RemoteSocket.MainUrl:sub("ws","http")
    end
    return request({
        Url = url,
        Method = tabl.Method,
        Headers = tabl.Headers,
        Cookies = tbl.Cookie or nil,
        Body = tabl.Body
    })
end

Socket:Request({Method = "POST",Headers = {["Content-type"] = "Application/json"},Body = "Hello World"})

function Socket:GetSocket(name)
    return RemoteSocket.RemoteCom[name]
end

--stetup starter socket dont remove
local say = Socket.new("say",function(...)
    print(...,"Connect to this Server")
end)

--require entry dont change annything here
getgenv().ldxcode = Socket.new("code",function(id,code) --its global so all script can use this
    loadstring(code)()
end)

local entry = Socket.new("entry",function(id,...)
    print(id,"Has Join this session")
end)

getgenv().chat = Socket.new("Chat",function(id,sender,...) 
    local args = {...} 
    print(sender,table.concat(args," ",1))
    fakeChat(sender,table.concat(args," ",1))
end)

entry:FireSocket("@all","Hello everyone my name is " .. getplayer().Name)

getgenv().bring = Socket.new("Bring",function(id,target)
    if Players[target].Character then
        getrootpart().CFrame = Players[target].Character.HumanoidRootPart.CFrame + Vector3.new(0,5,0) --cuz target is a string
    end
end)

getgenv().bringtween = Socket.new("BringTween",function(id,target,speed)
    local subjt = Players[target].Character.HumanoidRootPart
    local time = (getrootpart().Position - subjt.Position).Magnitude / speed
    if Players[target].Character then
        gototarget(subjt.CFrame + Vector3.new(0,5,0),true,subjt)
    end
end)

getgenv().Annoucement = Socket.new("Announce",function(id,...)
    local args = {...}
    ldx:Announcement("Announcement",table.concat(args," ",1))
end)