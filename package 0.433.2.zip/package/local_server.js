// config
const config = {
    refresh_stat: 10
}
//simple ws send and recive
/*
==note==
%name% used for client who run liex
__name__ use for server to manager or manager to server
*/
const WebSocket = require("ws")
const fs = require("fs")
const os = require("os")
const wss = new WebSocket.Server({ port: 3000 })
const crypto = require("crypto");
const { spawn } = require("child_process");
const path = require("path");
/*
exmpl data
data = {
    clientId:1,
    fpscap:30,
    network:18ms,
    limitkbpssend:500,
}
*/

const codes = crypto.randomUUID()
fs.writeFileSync("./logs"+codes+".txt", "---LOGS---")
let webws = null
let clientdata = {}
let serverdata = {
    limit:{
        fps: 0,
        send:0
    },
    stats:{
        avgpingclient:{},
        avgfpsclient:{},
        avgmemclient:{},
        avggpuclient:{},
        clients: 0
    }
}
let shared = {}

function UpdateServerData(){
    try{
        let statping = 0
        let statmem = 0
        let statfps = 0
        let statgpu = 0
        const count = Object.keys(clientdata).length
        Object.values(clientdata).forEach(cli =>{
            console.log(cli.data)
            statping += cli.data.ping
            statfps += cli.data.fps
            statmem += cli.data.mem
            statgpu += cli.data.gpu
        })
        const tbl = serverdata.stats
        tbl.avgpingclient = statping / count
        tbl.avggpuclient = statgpu / count
        tbl.avgfpsclient = statfps / count
        tbl.avgmemclient = statmem / count
        serverdata.stats.clients = count
        console.log(serverdata.stats)
    } catch(err) {console.log(err)}
    try{
        webws.send(JSON.stringify({name:"__SERVER_DATA__",opr:"@Manager",args:serverdata}))
    } catch(err){return false}
}

function ignoreCall(f){
    let er
    let suc = true
    try { f() } catch(err) { er = err; suc = false}
    return [suc,er]
}

let pid = crypto.randomUUID()
console.log("new PID:",pid)
wss.on("connection", function(ws) {
    
    if (ws.readyState == WebSocket.OPEN) {
        ws.send("|ConnectedToSocket|")
    }
    ws.on("message", async function(message) {
        const text = message.toString()
        let datajs;
        try {
            datajs = JSON.parse(text)
            console.log(datajs)
            if (datajs.invoke) {
                let shared = fs.readFileSync("./shared/global_variable.json")
                if (datajs.name === "__Heartbeat__" && datajs.opr === "@Socket"){
                    clientdata[datajs.args.who].data = datajs.args
                    console.log(datajs)
                }
                else if (datajs.name === "__GetData__" && datajs.opr === "@Socket"){
                    try{
                        console.log("fetching")
                        ws.send(JSON.stringify({name:"__USERDATA__",data:clientdata,opr:"@Manager"}))
                    } catch(err){
                        console.log("failed to fetch")
                        ws.send("Invalid User id user is not exist or not heartbeated yet")
                    }
                }
                else if (datajs.name === "__Shared__" && datajs.opr === "@Socket"){
                    if (datajs.args[0] === "GET"){
                        ws.send(JSON.stringify({name:"__Shared__",opr:"@self",args:shared[datajs.args[1]]}))
                        return
                    }
                    if (datajs.args[0] === "POST"){
                        shared[datajs.args[1]] = datajs.args[2]
                    }
                    console.log(datajs)
                }
            }
            if (datajs.name == "__Entry__" && datajs.opr === "@Manager"){
                    const args = datajs.args
                    ws.Name = args[5]
                    let uri = "https://thumbnails.roblox.com/v1/users/avatar?size=420x420&isCircular=false&format=png&userIds="+datajs.id.toString()
                    try {
                        const res = await fetch(uri)
                        const data = await res.json()
                        uri = data.data[0].imageUrl || uri
                    } catch(er) {}
                    clientdata[args[5]] = {
                        DeviceId:args[0],
                        UserId:datajs.id,
                        SessionId:args[1],
                        PlaceId:args[2],
                        JobId:args[3],
                        Profile:uri,
                        Name:args[5],
                        data:{}
                    }
                    try{
                        webws.send(JSON.stringify({name:"__Client__",opr:"@Manager",id:"Added",data:clientdata[args[5]]}))
                    } catch(er) {ws.send("invalid web ws")}
                }
        } catch(err) {}
        if (text === "__web__") {
            webws = ws
            ws.send("IP: " + ws._socket.remoteAddress + "|Port: " + ws._socket.remotePort)
            setTimeout(()=>{ws.send("$Session-"+pid)},50)
            setTimeout(()=>{},100)
        }
        if (text === "ping") {
            ws.send("pong")
            return
        }
        if (text === "%UpdateData%"){
            wss.clients.forEach(function(client){
                client.send("%GetUserData%")
            })
        }
        if (text.includes("Invoke")){
            const dat = text.split(":;:")
            if (dat[0] === "Invoke" && invokeEvent[dat[1]] != null) {
                invokeEvent[dat[1]].func(...dat)
            }
        }
        if (text.includes("@Manager")) {
            if (webws != null) {
                webws.send(text)
            }
        }
        wss.clients.forEach(function(client){

            if(client.readyState === WebSocket.OPEN) {
                client.send(text)
            }
        })
    })
    ws.on("close",function(){
        console.log(ws.Name)
        delete clientdata[ws.Name]
        if (ws === webws) {
            webws = null
        }
    try{
        webws.send(JSON.stringify({name:"__Client__",opr:"@Manager",id:"Removing",args:[ws.Name]}))
    } catch(err){console.log("No Manager Connected")}
    })
})
setTimeout(async () => {
    try {
        const res = await fetch("http://127.0.0.1:4040/api/tunnels");
        const data = await res.json();

        if (data.tunnels?.length) {
            console.log("Server Run", data.tunnels[0].public_url);
        } else {
            console.log("Ngrok belum siap");
        }
    } catch {
        console.log("Ngrok tidak berjalan");
    }
}, 2000);
setInterval(() => {
    UpdateServerData()
}, config.refresh_stat * 1000);
const sleep = (s) => new Promise(resolve => setTimeout(resolve, s * 1000));