first run
ngrok
second run
```bash
ngrok config add-authtoken $YOUR_AUTHTOKEN
```
third
```bash
ngrok ngrok http $YOUR_PORT
```
fourth
go to
```bash
cd $YOUR_SERVER_PATH
```
fifth
run node
```bash
node local_server.js
```
sixth
copy url from ngrok
```bash
Forwarding : $COPY_URL
```
seventh
replace http:// or https:// to ws:// or wss://

final step
run script