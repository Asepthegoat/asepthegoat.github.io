//simple ws send and recive
const WebSocket = require("ws")
const fs = require("fs")

const wss = new WebSocket.Server({ port: 3000 })
const crypto = require("crypto");

/*
exmpl data
data = {
    clientId:1,
    fpscap:30,
    network:18ms,
    limitkbpssend:500,
}
*/
const codes = crypto.randomUUID()
fs.writeFileSync(__dirname + "create.code", codes)
let webws = null

let invokeEvent = []
wss.on("connection", function(ws) {
const gethost = false
    function newInvokeEvent(name,func) {
        invokeEvent[name].callback = func
    }
    if (ws.readyState == WebSocket.OPEN) {
        ws.send("|ConnectedToSocket|")
    }
    ws.on("message", function(message) {
        const text = ""
        if (text === "%web%") {
            webws = ws
            ws.send("IP: " + ws._socket.remoteAddress + "|Port: " + ws._socket.remotePort)
            setTimeout(()=>{ws.send("$Session-"+crypto.randomUUID())},50)
        }
        if (text === "%GetData%"){
            ws.send(wss.clients.size + " | ")
        }
        if (text === "%UpdateData%"){
            wss.clients.forEach(function(client){
                client.send("%GetUserData%")
            })
        }
        if (text.includes("Invoke")){
            const dat = text.split(":;:")
            if (dat[0] === "Invoke" && invokeEvent[dat[1]] != null) {
                invokeEvent[dat[1]].func(...dat)
            }
        }
        if (text.includes("@WebApp")) {
            if (webws != null) {
                webws.send(text)
            }
        }
        wss.clients.forEach(function(client){

            if(client.readyState === WebSocket.OPEN) {
                client.send(text)
            }
        })
    })
    ws.on("close",function(){
        if (ws === webws) {
            webws = null
        }
    })
})

const sleep = (s) => new Promise(resolve => setTimeout(resolve, s * 1000));