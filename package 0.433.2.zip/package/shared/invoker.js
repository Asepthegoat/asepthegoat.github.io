let signal = {}
export default class Invoke {
  constructor(nama,func) {
    this.nama = nama
    this.func = func
  }

  invoke() {
    signal[this.nama] = this.func
    return signal[this.nama]
  }
}
