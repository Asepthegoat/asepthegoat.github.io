for i,v in pairs(getreg()) do
 if typeof(v) == "thread" then 
  coroutine.close(v) 
  task.cancel(v) 
 end 
end